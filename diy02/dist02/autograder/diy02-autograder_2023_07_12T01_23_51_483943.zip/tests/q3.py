OK_FORMAT = True

test = {   'name': 'q3',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> med_msrp != ...\nTrue', 'failure_message': 'Did you forget to enter an expression?', 'hidden': False, 'locked': False},
                                   {'code': '>>> isinstance(med_msrp, float)\nTrue', 'failure_message': 'Check your data type.', 'hidden': False, 'locked': False},
                                   {'code': '>>> med_msrp == 31950.0\nTrue', 'failure_message': 'Check your calculation.', 'hidden': False, 'locked': False},
                                   {'code': '>>> med_msrp\n31950.0', 'failure_message': 'Check your calculation.', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
