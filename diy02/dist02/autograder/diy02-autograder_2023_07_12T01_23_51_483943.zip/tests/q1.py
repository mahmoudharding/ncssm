OK_FORMAT = True

test = {   'name': 'q1',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> top10_gross != ...\nTrue', 'failure_message': 'Did you forget to enter an expression?', 'hidden': False, 'locked': False},
                                   {'code': '>>> isinstance(top10_gross, tables.Table)\nTrue', 'failure_message': 'Check your data type.', 'hidden': False, 'locked': False},
                                   {'code': '>>> top10_gross.num_rows == 10\nTrue', 'failure_message': 'Do you have the correct number of rows?', 'hidden': False, 'locked': False},
                                   {'code': ">>> top10_gross.take(0).column('Gross').item(0) == 936.7\nTrue", 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
