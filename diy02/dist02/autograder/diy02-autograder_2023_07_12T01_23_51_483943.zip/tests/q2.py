OK_FORMAT = True

test = {   'name': 'q2',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> avg_son_height != ...\nTrue', 'failure_message': 'Did you forget to enter an expression?', 'hidden': False, 'locked': False},
                                   {'code': '>>> isinstance(avg_son_height, float)\nTrue', 'failure_message': 'Check your data type.', 'hidden': False, 'locked': False},
                                   {   'code': '>>> import math\n>>> math.isclose(70.45, avg_son_height, rel_tol=0.001)\nTrue',
                                       'failure_message': 'Did you perform the correct calculation?',
                                       'hidden': False,
                                       'locked': False},
                                   {'code': '>>> avg_son_height\n70.454748603351959', 'failure_message': 'Did you perform the correct calculation?', 'hidden': False, 'locked': False},
                                   {'code': '>>> avg_son_height\n70.454748603351959', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
