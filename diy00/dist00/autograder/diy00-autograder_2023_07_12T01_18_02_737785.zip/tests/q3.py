OK_FORMAT = True

test = {   'name': 'q3',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> secs_in_week != ...\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> isinstance(secs_in_week, int)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> secs_in_week == 604800\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
