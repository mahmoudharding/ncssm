OK_FORMAT = True

test = {'name': 'q1', 'points': None, 'suites': [{'cases': [{'code': '>>> secs_in_week == 604800\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
