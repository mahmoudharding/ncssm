OK_FORMAT = True

test = {   'name': 'q2',
    'points': None,
    'suites': [   {   'cases': [{'code': '>>> secs_in_week == 604800\nTrue', 'hidden': False, 'locked': False}, {'code': '>>> type(secs_in_week) == int\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
