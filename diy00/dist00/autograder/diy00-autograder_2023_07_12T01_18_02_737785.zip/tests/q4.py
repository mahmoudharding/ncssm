OK_FORMAT = True

test = {   'name': 'q4',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> secs_in_week != ...\nTrue', 'failure_message': 'Did you forget to enter an expression?', 'hidden': False, 'locked': False},
                                   {'code': '>>> isinstance(secs_in_week, int)\nTrue', 'failure_message': 'Check the data type of your result.', 'hidden': False, 'locked': False},
                                   {'code': '>>> secs_in_week == 604800\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
