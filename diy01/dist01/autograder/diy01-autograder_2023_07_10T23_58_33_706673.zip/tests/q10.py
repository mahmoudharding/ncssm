OK_FORMAT = True

test = {   'name': 'q10',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> current_year != ...\nTrue', 'failure_message': 'Did you forget to enter an expression?', 'hidden': False, 'locked': False},
                                   {'code': '>>> isinstance(current_year, float)\nTrue', 'failure_message': 'Check your data type.', 'hidden': False, 'locked': False},
                                   {'code': '>>> current_year == 2023.0\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
